﻿using System;

namespace $safeprojectname$.Contracts
{
    [AttributeUsage(AttributeTargets.Property)]
    public class SuppressAttribute : Attribute { }
}
