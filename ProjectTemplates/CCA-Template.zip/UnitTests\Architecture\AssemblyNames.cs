﻿using System;

namespace $safeprojectname$.Architecture
{
    internal class AssemblyNames
    {
        internal const string Domain = "$ext_safeprojectname$.Domain";
        internal const string Application = "$ext_safeprojectname$.Application";
        internal const string PresentationWeb = "$ext_safeprojectname$.Presentation.Web";
        internal const string Persistence = "$ext_safeprojectname$.Persistence";
        internal const string Resources = "$ext_safeprojectname$.Resources";
    }
}
