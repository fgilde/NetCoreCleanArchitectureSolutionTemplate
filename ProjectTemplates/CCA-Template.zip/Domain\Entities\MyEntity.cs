﻿using System;

namespace $safeprojectname$.Entities
{
    public class MyEntity : EntityBase
    {
        public string Name { get; set; }
    }
}