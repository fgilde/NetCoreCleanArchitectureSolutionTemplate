﻿using $ext_safeprojectname$.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$
{
	public class DataContext : DbContext
	{
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {
            this.Database.Migrate();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
			    => modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
	}
}
