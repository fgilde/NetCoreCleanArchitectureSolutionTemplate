﻿using System;

namespace $safeprojectname$.Contracts
{
    public interface IDateProvider
    {
        DateTime Today { get; }
    }
}
