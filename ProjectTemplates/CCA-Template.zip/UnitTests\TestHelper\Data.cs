﻿using System;

namespace $safeprojectname$.TestHelper
{
    // TestFacade for Testdata

    public static class Data
    {
        public static class Ids
        {
            public const int Foobar = 42;
        }
    }
}
