﻿namespace $safeprojectname$
{
    public class Constants
    {
        public const string ApplicationName = "$ext_safeprojectname$";

        public static class Environment
        {
            public const string Testing = nameof(Testing);
            public const string Development = nameof(Development);
            public const string Production = nameof(Production);
        }
    }
}
